import Link from "next/link";
import type { ReactNode } from "react";
import { DOCUMENTS_CSS } from "./styles.ts";

export type Section = "documents" | "templates" | "profile";

const SECTIONS: { id: Section; label: string; href: string }[] = [
  { id: "documents", label: "Documents", href: "/documents" },
  { id: "templates", label: "Templates", href: "/documents/templates" },
  { id: "profile", label: "Profile", href: "/documents/settings" },
];

/** Page bar shared by every page of the module: title and description on the left, the module's sections on the right. */
export function PageBar({ title, description, current, actions }: { title: string; description?: ReactNode; current: Section; actions?: ReactNode }) {
  return (
    <>
    <style>{DOCUMENTS_CSS}</style>
    <header className="page-bar">
      <div className="page-bar-text">
        <h1>{title}</h1>
        {description ? <p>{description}</p> : null}
      </div>
      <nav className="page-bar-tools" aria-label="Documents sections">
        <div className="page-tabs">
          {SECTIONS.map((section) => (
            <Link key={section.id} href={section.href} aria-current={section.id === current ? "page" : undefined}>
              {section.label}
            </Link>
          ))}
        </div>
        {actions}
      </nav>
    </header>
    </>
  );
}
