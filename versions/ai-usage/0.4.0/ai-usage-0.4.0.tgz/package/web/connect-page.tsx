import { getDb } from "@modunexo/sdk";
import type { Metadata } from "next";
import { headers } from "next/headers";
import { SCOPE, connectSteps, originOf } from "../lib/connect.ts";
import { Portlet } from "./components.tsx";
import "./ai-usage.css";

export const metadata: Metadata = { title: "Connect a machine" };

interface Received {
  tool: string;
  events: number;
  last: Date;
}

async function loadReceived(): Promise<Received[] | null> {
  try {
    const { rows } = await getDb("ai-usage").query<{ tool: string; events: string; last: Date }>(
      "select t.name as tool, count(*) as events, max(e.occurred_at) as last from ai_usage.usage_events e join ai_usage.tools t on t.id = e.tool_id group by t.name order by t.name",
    );
    return rows.map((row) => ({ tool: row.tool, events: Number(row.events), last: row.last }));
  } catch {
    return null;
  }
}

export default async function ConnectPage() {
  const steps = connectSteps(originOf(await headers()));
  const received = await loadReceived();
  return (
    <div className="au">
      <header className="page-bar">
        <div className="page-bar-text">
          <h1>Connect a machine</h1>
          <p>How the AI tools on a computer send their token usage here.</p>
        </div>
      </header>
      <div className="page-body au-layout">
        <Portlet label="How it connects" title="How it connects" note="There is nothing to configure in the platform settings: the machine that holds the logs does the sending.">
          <ul>
            <li>It uses the API, not a password: a service token, sent as <code>Authorization: Bearer &lt;token&gt;</code>.</li>
            <li>The token needs the scope <code>{SCOPE}</code> of this module and nothing else, so it cannot read or change any other module.</li>
            <li>Only counters, model names, dates and a project name are sent. Never prompts, answers or file paths.</li>
            <li>Sending again is safe: nothing is counted twice.</li>
          </ul>
          <p>Address that receives the data:</p>
          <pre className="au-code">{steps.endpoint}</pre>
        </Portlet>
        <Portlet label="Set it up" title="Set it up" note="The same three values (address, token, scope) are what the desktop agent will ask for.">
          <ol>
            <li>
              On the platform server, create the token (it is shown once):
              <pre className="au-code">{steps.createToken}</pre>
            </li>
            <li>
              On the computer with the AI tools, see what would be sent. Nothing leaves the machine:
              <pre className="au-code">{steps.preview}</pre>
            </li>
            <li>
              Send it for real:
              <pre className="au-code">{steps.send}</pre>
            </li>
          </ol>
        </Portlet>
        <Portlet label="What arrived" title="What arrived">
          {received === null ? (
            <p>The data could not be read.</p>
          ) : received.length === 0 ? (
            <p>Nothing has arrived yet.</p>
          ) : (
            <ul>
              {received.map((row) => (
                <li key={row.tool}>
                  {row.tool}: {row.events.toLocaleString("en-US")} events, the latest on {row.last.toISOString().slice(0, 16).replace("T", " ")} UTC
                </li>
              ))}
            </ul>
          )}
        </Portlet>
      </div>
    </div>
  );
}
