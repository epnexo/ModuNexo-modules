export const SCOPE = "ai_usage.write";
export const INGEST_PATH = "/svc/ai-usage/ingest";

/** The address people use to reach this platform, from the headers the proxy in front of it sets. */
export function originOf(headers: { get(name: string): string | null }): string {
  const host = headers.get("x-forwarded-host") ?? headers.get("host");
  if (!host || !/^[A-Za-z0-9.-]+(:\d{1,5})?$/.test(host)) return "https://<your-platform>";
  const proto = headers.get("x-forwarded-proto")?.split(",")[0]?.trim();
  return `${proto === "http" ? "http" : "https"}://${host}`;
}

/** What someone needs to connect a machine: the values to copy, in the order to use them. */
export function connectSteps(origin: string) {
  return {
    endpoint: `${origin}${INGEST_PATH}`,
    createToken: `npm run modunexo -- tokens create ai-usage --name "my-laptop" --scope ${SCOPE} --expires-in-days 90`,
    preview: "node --import tsx src/cli/ingest.ts --dry-run",
    send: `AI_USAGE_TOKEN=<the token> node --import tsx src/cli/ingest.ts --url ${origin}`,
  };
}
