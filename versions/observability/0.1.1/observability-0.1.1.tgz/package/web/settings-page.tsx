export const metadata = { title: "Observability settings" };

export default function ObservabilitySettingsPage() {
  return <main><header><h1>Collector configuration</h1><p>Collectors connect outbound to this platform. Keep tokens and CA files outside command arguments and logs.</p></header><section><h2>Enrollment</h2><ol><li>Create a service token with the <code>collectors.write</code> scope.</li><li>Save the token in a root-readable file on the host.</li><li>Save the internal CA bundle beside the configuration file.</li><li>Configure the platform HTTPS URL and heartbeat interval.</li><li>Install and start the systemd service.</li></ol></section><section><h2>Configuration file</h2><pre>{`{"platformURL":"https://platform.example.test","tokenFile":"/etc/modunexo-agent/token","caFile":"/etc/modunexo-agent/ca.pem","heartbeatInterval":"1m"}`}</pre><p>The module shows a collector as connected after its authenticated heartbeat arrives.</p></section></main>;
}
