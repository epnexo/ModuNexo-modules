import { getDb } from "@modunexo/sdk";

export const metadata = { title: "Observability" };

export default async function ObservabilityPage() {
  const { rows } = await getDb("observability").query<{ host_name: string; version: string; capabilities: string[]; payload_shape: Record<string, string>; last_seen_at: Date | null }>("select host_name, version, capabilities, payload_shape, last_seen_at from collectors order by host_name");
  const connected = rows.filter((collector) => collector.last_seen_at).length;
  return <main>
    <header><h1>Observability</h1><p>Manage collectors, inspect their declared capabilities, and verify their outbound connection health.</p></header>
    <section aria-label="Collector summary"><dl><div><dt>Collectors</dt><dd>{rows.length}</dd></div><div><dt>Connected</dt><dd>{connected}</dd></div><div><dt>Attention needed</dt><dd>{rows.length - connected}</dd></div></dl></section>
    <section aria-labelledby="collectors-heading"><h2 id="collectors-heading">Collectors</h2><p>A collector is connected only after its authenticated heartbeat reaches this module.</p>{rows.length === 0 ? <p>No collectors have connected yet. Configure a service token and internal CA in the collector, then wait for its first heartbeat.</p> : <table><thead><tr><th scope="col">Collector</th><th scope="col">Status</th><th scope="col">Version</th><th scope="col">Capabilities</th><th scope="col">Payload shape</th><th scope="col">Last heartbeat</th></tr></thead><tbody>{rows.map((collector) => <tr key={collector.host_name}><th scope="row">{collector.host_name}</th><td>{collector.last_seen_at ? "Connected" : "Not connected"}</td><td>{collector.version}</td><td>{collector.capabilities.length ? collector.capabilities.join(", ") : "Not collected"}</td><td>{Object.keys(collector.payload_shape).length ? Object.entries(collector.payload_shape).map(([key, type]) => `${key}: ${type}`).join(", ") : "Not collected"}</td><td>{collector.last_seen_at?.toISOString() ?? "No heartbeat"}</td></tr>)}</tbody></table>}</section>
  </main>;
}
