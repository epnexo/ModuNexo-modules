import { SDK_VERSION, defineModule } from "@modunexo/sdk";

export default defineModule({
  id: "observability",
  version: "0.2.0",
  name: "Observability",
  platform: `^${SDK_VERSION}`,
  dependsOn: {},
  schema: "observability",
  migrationsDir: "migrations",
  permissions: [
    { key: "observability.read", label: "Read fleet health and metrics" },
    { key: "observability.admin", label: "Manage observability collectors" },
  ],
  scopes: [{ key: "collectors.write", label: "Send collector telemetry" }],
  settings: [
    { key: "collector_ca", label: "Collector CA certificate", type: "secret", description: "CA certificate trusted by outbound collectors." },
    { key: "alert_webhook_url", label: "Alert webhook address", type: "string", description: "Where alerts are posted as JSON (for example an n8n webhook). Leave empty to send none." },
    { key: "alert_webhook_secret", label: "Alert webhook secret", type: "secret", description: "Sent as a bearer token with every alert. Optional." },
  ],
  events: [{ name: "alert" }],
  subscriptions: [{ event: "observability.alert", job: "notify" }],
  nav: [{ label: "Observability", href: "/observability", icon: "activity", permission: "observability.read" }],
  dashboard: {
    stats: [{ key: "collectors", label: "Collectors", href: "/observability", permission: "observability.read", sql: "select count(*) from collectors" }],
    alerts: [{ key: "offline_collectors", label: "Collectors offline", href: "/observability", severity: "warning", permission: "observability.read", sql: "select count(*) from collectors where last_seen_at is null or last_seen_at < now() - interval '10 minutes'" },
      { key: "firing_alerts", label: "Alerts firing", href: "/observability", severity: "warning", permission: "observability.read", sql: "select count(*) from alerts where state = 'firing'" },
    ],
  },
  jobs: [
    { name: "rollup", entry: "./jobs/rollup.ts", every: "1h" },
    { name: "retention", entry: "./jobs/retention.ts", every: "1d" },
    { name: "evaluate", entry: "./jobs/evaluate.ts", every: "1m", timeoutSeconds: 50 },
    { name: "notify", entry: "./jobs/notify.ts", timeoutSeconds: 30, maxAttempts: 5 },
  ],
  pages: [
    { path: "/observability", entry: "./web/observability-page.tsx", kind: "page", dynamic: "force-dynamic", permission: "observability.read" },
    { path: "/observability/collector/[host]", entry: "./web/collector-page.tsx", kind: "page", dynamic: "force-dynamic", permission: "observability.read" },
    { path: "/observability/alerts", entry: "./web/alerts-page.tsx", kind: "page", dynamic: "force-dynamic", permission: "observability.read" },
    { path: "/observability/rules", entry: "./web/rules-page.tsx", kind: "page", dynamic: "force-dynamic", permission: "observability.admin" },
    { path: "/observability/rules/save", entry: "./web/rule-save.ts", kind: "route", methods: ["POST"], permission: "observability.admin" },
    { path: "/observability/settings", entry: "./web/settings-page.tsx", kind: "page", dynamic: "force-dynamic", permission: "observability.admin" },
    { path: "/svc/observability/heartbeat", entry: "./web/heartbeat.ts", kind: "route", methods: ["POST"], scope: "collectors.write" },
    { path: "/svc/observability/ingest", entry: "./web/ingest.ts", kind: "route", methods: ["POST"], scope: "collectors.write" },
    { path: "/svc/observability/events", entry: "./web/events.ts", kind: "route", methods: ["POST"], scope: "collectors.write" },
  ],
});
